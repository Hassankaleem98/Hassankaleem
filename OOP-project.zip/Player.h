#pragma once
#include<string>
using namespace std;


class Player {
public:
	Player(string username, string password);
	string getUsername();
	bool checkPassword(string p);
	void saveBadges(string badge);
	void viewBadges();
	static Player* loginOrSignup();
	static void viewLeaderboard();
private:
	string username;
	string password;

	static Player* signUp();
	static Player* login();
};