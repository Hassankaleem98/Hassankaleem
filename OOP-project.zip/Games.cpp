#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <map>
#include <cstdlib>
#include <ctime>
#include<vector>
#include "Player.h"
#include "Game.h"
#include "Games.h"


using namespace std;


void MathChallenge::play() {
    int a = rand() % 10 + 1, b = rand() % 10 + 1;
    int correctAnswer = a + b, userAnswer;
    cout << "Solve: " << a << " + " << b << " = ";
    cin >> userAnswer;
    if (userAnswer == correctAnswer) {
        cout << "Correct! You earned a Math Badge.\n";
        this->player->saveBadges("Math Badge");
    }
    else {
        cout << "Wrong! The correct answer was " << correctAnswer << ".\n";
    }
}



void Anagrams::play() {
    vector<string> words;
    string filename = "words.txt"; // File containing words

    // Open the file and read words into the vector
    ifstream file(filename);
    if (!file) {
        cerr << "Error: Unable to open file " << filename << endl;
        return;
    }

    string word;
    while (file >> word) {
        words.push_back(word); // Add each word to the vector
    }
    file.close();

    if (words.empty()) {
        cerr << "Error: No words found in file!" << endl;
        return;
    }

    // Select a random word
    string selectedWord = words[rand() % words.size()];
    string shuffled = selectedWord;
    random_shuffle(shuffled.begin(), shuffled.end());

    // Play the game
    cout << "Unscramble this word: " << shuffled << endl;
    string guess;
    cin >> guess;

    if (guess == selectedWord) {
        cout << "Correct! You earned an Anagrams Badge.\n";
        player->saveBadges("Anagrams Badge");
    }
    else {
        cout << "Wrong! The word was " << selectedWord << ".\n";
    }
}


void MissingNumber::play() {
    int start = rand() % 10 + 1;
    int step = rand() % 5 + 1;
    int missingIndex = rand() % 5;
    vector<int> sequence;
    for (int i = 0; i < 5; ++i) {
        sequence.push_back(start + i * step);
    }
    int missingNumber = sequence[missingIndex];
    sequence[missingIndex] = -1;
    cout << "Find the missing number: ";
    for (int num : sequence) {
        if (num == -1) cout << "_ ";
        else cout << num << " ";
    }
    cout << endl;
    int guess;
    cin >> guess;
    if (guess == missingNumber) {
        cout << "Correct! You earned a Missing Number Badge.\n";
        this->player->saveBadges("Missing Number Badge");
    }
    else {
        cout << "Wrong! The number was " << missingNumber << ".\n";
    }
}

void GuessGame::play() {
    int target = rand() % 100 + 1; // Random number between 1 and 100
    int guess;

    cout << "Guess a number between 1 and 100: ";
    cin >> guess;

    if (guess == target) {
        cout << "Correct! You earned a Guess Game Badge.\n";
        this->player->saveBadges("Guess Game Badge");
    }
    else {
        cout << "Wrong! The correct number was " << target << ".\n";
    }
}
