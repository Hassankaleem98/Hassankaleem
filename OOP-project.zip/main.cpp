#include"Games.h"
#include "Player.h"
#include "Game.h"
#include<vector>

using namespace std;



int main() {
    srand(time(0));
    Player* player = Player::loginOrSignup();
    if (!player) return 0;

    vector<Game*> games = {
        new MathChallenge(player),
        new Anagrams(player),
        new MissingNumber(player),
        new GuessGame(player)
    };

    while (true) {
        system("cls");
        cout << "1. Play a game\n2. View my badges\n3. View leaderboard\n4. Exit\nChoose an option: ";
        int choice;
        cin >> choice;
        if (choice == 1) {
            system("cls");
            int gameIndex = rand() % games.size();
            games[gameIndex]->play();
        }
        else if (choice == 2) {
            system("cls");
            player->viewBadges();
        }
        else if (choice == 3) {
            system("cls");
            Player::viewLeaderboard();
        }
        else if (choice == 4) {
            break;
        }
        system("pause");
    }

    return 0;
}
