#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <map>
#include <cstdlib>
#include <ctime>
#include "Player.h"
#include "Game.h"


class MathChallenge : public Game {
public:
    MathChallenge(Player* p) : Game("Math Challenge", p) {}
    void play() override;
};

class Anagrams : public Game {
public:
    Anagrams(Player* p) : Game("Anagrams", p) {}
    void play() override;
};

class MissingNumber : public Game {
public:
    MissingNumber(Player* p) : Game("Missing Number", p) {}
    void play() override;
};


class GuessGame : public Game {
public:
    GuessGame(Player* p) : Game("Missing Number", p) {}
    void play() override;
};