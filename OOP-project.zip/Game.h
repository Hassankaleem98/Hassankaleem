#pragma once
#include"Player.h"
#include<iostream>
#include<fstream>
#include<string>
using namespace std;

class Game {
public:
    Game(string t, Player* p) : title(t), player(p) {}
    virtual void play() = 0;
    string getTitle() { return title; }
    Player* player;

protected:
    string title;
};
