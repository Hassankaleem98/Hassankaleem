#include"Player.h"
#include<iostream>
#include<fstream>
#include<algorithm>
#include<string>
#include <map>

using namespace std;

Player::Player(string u, string p) : username(u), password(p) {}

string Player::getUsername() {
    return username;
}

bool Player::checkPassword(string p) {
    return p == password;
}

void Player::viewBadges() {
    string filename = username + "_badges.txt";
    ifstream inFile(filename);
    if (!inFile.is_open()) {
        cout << "No Badges Found" << endl;
    }
    else {
        cout << "Your Badges:" << endl;
        string badge;
        while (getline(inFile, badge)) {
            cout << "- " << badge << endl;
        }
        inFile.close();
    }
}

Player* Player::loginOrSignup() {
    cout << "1. Sign Up\n2. Log In\nChoose an option: ";
    int choice;
    cin >> choice;
    if (choice == 1) {
        return signUp();
    }
    else if (choice == 2) {
        return login();
    }
    return nullptr;
}

void Player::viewLeaderboard() {
    map<string, int> leaderboard;
    ifstream inFile("leaderboard.txt");
    string player, badge;
    while (inFile >> player >> badge) {
        leaderboard[player]++;
    }
    inFile.close();
    cout << "Leaderboard:\n";
    for (const auto& entry : leaderboard) {
        cout << entry.first << ": " << entry.second << " badges\n";
    }
}

void Player::saveBadges(string badge) {
    ofstream outFile(username + "_badges.txt", ios::app);
    outFile << badge << endl;
    outFile.close();

    // Update leaderboard
    ofstream leaderboard("leaderboard.txt", ios::app);
    replace(badge.begin(), badge.end(), ' ', '_');
    leaderboard << username << " " << badge << endl;
    leaderboard.close();
}

Player* Player::signUp() {
    cout << "Enter username: ";
    string username, password;
    cin >> username;
    cout << "Enter password: ";
    cin >> password;
    ofstream outFile("players.txt", ios::app);
    outFile << username << " " << password << endl;
    outFile.close();
    return new Player(username, password);
}

Player* Player::login() {
    cout << "Enter username: ";
    string username, password;
    cin >> username;
    cout << "Enter password: ";
    cin >> password;
    ifstream inFile("players.txt");
    string user, pass;
    while (inFile >> user >> pass) {
        if (user == username && pass == password) {
            return new Player(username, password);
        }
    }
    cout << "Invalid credentials.\n";
    return nullptr;
}

